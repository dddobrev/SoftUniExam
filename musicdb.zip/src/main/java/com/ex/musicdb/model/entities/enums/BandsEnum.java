package com.ex.musicdb.model.entities.enums;

public enum BandsEnum {
    QUEEN, METALLICA, MADONNA
}
