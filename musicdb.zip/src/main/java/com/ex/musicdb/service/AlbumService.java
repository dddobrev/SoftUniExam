package com.ex.musicdb.service;

import com.ex.musicdb.model.service.AlbumServiceModel;

public interface AlbumService {
    void add(AlbumServiceModel albumServiceModel);
}
