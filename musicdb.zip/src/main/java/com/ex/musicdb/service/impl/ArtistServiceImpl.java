package com.ex.musicdb.service.impl;


import com.ex.musicdb.model.entities.ArtistEntity;
import com.ex.musicdb.model.entities.enums.BandsEnum;
import com.ex.musicdb.repository.ArtistRepository;
import com.ex.musicdb.service.ArtistService;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class ArtistServiceImpl implements ArtistService {

    private final ArtistRepository artistRepository;

    public ArtistServiceImpl(ArtistRepository artistRepository) {
        this.artistRepository = artistRepository;
    }

    @Override
    public void initArtist() {
        if (artistRepository.count()==0){
            Arrays.stream(BandsEnum.values())
                    .forEach(bandsEnum -> {
                        ArtistEntity artist = new ArtistEntity();
                        artist.setName(bandsEnum.name());
                        artistRepository.save(artist);
                    });
        }
    }
}
