package com.ex.musicdb.service;

public interface ArtistService {
    void initArtist();

}
